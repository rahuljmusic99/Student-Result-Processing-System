document.getElementById("add");
function myFunction1(){
  document.querySelector('.bg-model').style.display = 'flex';
  document.querySelector('.bg-model').style.position = 'fixed';
}
                    
        
document.getElementById("circle1");
function myFunction6(){
  document.querySelector('.bg-model3').style.display = 'flex';
  document.querySelector('.bg-model3').style.position = 'fixed';
}
        
        

        
        
document.getElementById("circle2");
function myFunction7(){
 document.querySelector('.bg-model4').style.display = 'flex';
 document.querySelector('.bg-model4').style.position = 'fixed';
}


document.getElementById("add1");
function myFunction8(){
  document.querySelector('.bg-model5').style.display = 'flex';
  document.querySelector('.bg-model5').style.position = 'fixed';
}


document.getElementById("add2");
function myFunction9(){
  document.querySelector('.bg-model6').style.display = 'flex';
  document.querySelector('.bg-model6').style.position = 'fixed';
}

       
  
document.getElementById("add2");
function myFunction12(){
   document.querySelector('.bg-model9').style.display = 'flex';
    document.querySelector('.bg-model9').style.position = 'fixed';

}
            

       
 
document.getElementById("btn-edit4");
function myFunction15(){
    document.querySelector('.bg-model12').style.display = 'flex';
    document.querySelector('.bg-model12').style.position = 'fixed';
}
                
document.getElementById("edit4");
function myFunction16(){
    document.querySelector('.bg-model13').style.display = 'flex';
    document.querySelector('.bg-model13').style.position = 'fixed';
}

   


document.getElementById("popdiv2");
function myFunction21(){
    document.querySelector('.bg-model17').style.display = 'flex';
    document.querySelector('.bg-model17').style.position = 'fixed';
}
       
             
            

        
        