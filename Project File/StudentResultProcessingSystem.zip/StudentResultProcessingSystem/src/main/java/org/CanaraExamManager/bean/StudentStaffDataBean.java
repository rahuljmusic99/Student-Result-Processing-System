package org.CanaraExamManager.bean;


public class StudentStaffDataBean {
	
	private String firstNameString = "";
	private String lastNameString = "";
	private String genderString = "";
	private String dobString = "";
	private String emailString = "";
	private String phoneString = "";
	private String addressString = "";
	private String pincodeString = "";
	private String cityString = "";
	private String districtString = "";
	private String stateString = "";
	private String yearOfJoiningString = "";
	private String programmeString = "";
	private String classString = "";
	private String currentSemesterString = "";
	private String registerNoString = "";
	private String passwordString = "";
	private String classYearString = "";
	private String roleString = "";
	private String temp = "";
	
	private String staffId = "";
	
	public void setfirstName(String firstNameString) {//1
		this.firstNameString = firstNameString;
	}
	
	public String getfirstName() {
		return this.firstNameString;
	}
	
	public void setLastName(String lastNameString) {//2
		this.lastNameString = lastNameString;
	}
	
	public String getLastName() {
		return this.lastNameString;
	}
	
	public void setGender(String genderString) {//3
		this.genderString = genderString;
	}
	
	public String getGender() {
		return this.genderString;
	}
	
	public void setDOB(String dobString) {//4
		this.dobString = dobString;
	}
	
	public String getDOB() {
		return this.dobString;
	}
	
	public void setEmail(String emailString) {//5
		this.emailString = emailString;
	}
	
	public String getEmail() {
		return this.emailString;
	}
	
	public void setPhone(String phoneString) {//6
		this.phoneString = phoneString;
	}
	
	public String getPhone() {
		return this.phoneString;
	}
	
	public void setAddress(String addressString) {//7
		this.addressString = addressString;
	}
	
	public String getAddress() {
		return this.addressString;
	}
	
	public void setPinCode(String pincodeString) {//8
		this.pincodeString = pincodeString;
	}
	
	public String getPinCode() {
		return this.pincodeString;
	}
	
	public void setCity(String cityString) {//9
		this.cityString = cityString;
	}
	
	public String getCity() {
		return this.cityString;
	}
	
	public void setDistrict(String districtString) {//10
		this.districtString = districtString;
	}
	
	public String getDistrict() {
		return this.districtString;
	}
	
	public void setYear(String yearOfJoiningString) {//11
		this.yearOfJoiningString = yearOfJoiningString;
	}
	
	public String getYear() {
		return this.yearOfJoiningString;
	}
	
	public void setProgramme(String programmeString) {//12
		this.programmeString = programmeString;
	}
	
	public String getProgramme() {
		return this.programmeString;
	}
	
	public void setClass(String classString) {//13
		this.classString = classString;
	}
	
	public String getclass() {
		return this.classString;
	}
	
	public void setCurrentSemester(String currentSemesterString) {//14
		this.currentSemesterString = currentSemesterString;
	}
	
	public String getCurrentSemester() {
		return this.currentSemesterString;
	}
	
	public void setRegNo(String registerNoString) {//15
		this.registerNoString = registerNoString;
	}
	
	public String getRegNo() {
		return this.registerNoString;
	}
	
	public void setPassword(String passwordString) {//16
		this.passwordString = passwordString;
	}
	
	public String getPassword() {
		return this.passwordString;
	}
	
	public void setState(String stateString) {//17
		this.stateString = stateString;
	}
	
	public String getState() {
		return this.stateString;
	}
	
	public void setClassYear(String classYearString) {
		this.classYearString = classYearString; 
	}

	public String getClassYear() {
		return this.classYearString; 
	}

	
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	
	public String getStaffId() {
		return this.staffId;
	}
	
	public void setRole(String roleString) {
		this.roleString = roleString;
	}
	
	public String getRole() {
		return this.roleString;
	}
	
	public void setTemp(String temp) {
		this.temp = temp;
	}
	
	public String getTemp() {
		return this.temp;
	}
	
}
